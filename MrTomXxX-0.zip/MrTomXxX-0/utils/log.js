const chalk = require('chalk');

module.exports = (data, option) => {
	switch (option) {
		case "warn":
			console.log(chalk.yellow('[ ❕ Its wrong ] » ') + data);
			break;
		case "error":
			console.log(chalk.red('[ ❕ Its wrong ] » ') + data);
			break;
		default:
			console.log(chalk.magenta(`${option} » `) + data);
			break;
	}
}

module.exports.loader = (data, option) => {
	switch (option) {
		case "warn":
			console.log(chalk.yellow('[ MrTomXxX ] » ') + data);
			break;
		case "error":
			console.log(chalk.red('[ MrTomXxX ] » ') + data);
			break;
		default:
			console.log(chalk.green('[ MrTomXxX ] » ') + data);
			break;
	}
}